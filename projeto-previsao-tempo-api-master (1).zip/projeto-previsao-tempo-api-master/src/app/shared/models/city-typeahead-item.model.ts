export interface CityTypeaheadItem {
  country: string;
  geonameid: number;
  name: string;
  subcountry: string;
}

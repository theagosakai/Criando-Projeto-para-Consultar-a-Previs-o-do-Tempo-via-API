export const environment = {
  production: true,
  apiKey: '6275f7003de6b2c24fe5cc14a9a74cd9',
};
